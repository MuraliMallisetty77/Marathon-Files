#ifndef PLANETYPE_H
#define PLANETYPE_H

enum class PlaneType
{
    NEO,
    JUMBO,
    LUXUURY
};

#endif // PLANETYPE_H
