#ifndef BATTERYTYPE_H
#define BATTERYTYPE_H

enum class BatteryType
{
    LITHIUM_ION,
    NICKEL_METAL_HYDRIDE
};

#endif // BATTERYTYPE_H
